package FileTransfer;

import java.io.*;	//io package for file stream
import java.net.*;	//net package for sockets 


public class Receiver extends Thread{		//Creation of thread with runnable interface
    int port;
    String ip;
    String target;
    File fl;		//object of file class
    Socket skt=null;	//object of socket class
    ObjectInputStream OIS = null;
    public Receiver(String ip,int port,String filename){	//Constructor of Receiver class
        this.ip=ip;
        this.port=port;
        target=filename;
    }
    public void run(){			//method of thread class 
        try{
            skt=new Socket(ip,port);	//initialization of socket object 
            OIS = new ObjectInputStream(skt.getInputStream());

            fl=(File)OIS.readObject();
            copy(fl,target);	//calling of private copy method 
        }catch(Exception e){
            e.printStackTrace();	//This function will provide details in which line exception is occured

        }
    }

    private void copy(File originalFile, String targetFile) throws IOException {	//Definition of copy class 

        FileInputStream in = null;	//object of file input stream
        FileOutputStream out = null;	//object of file output stream

        in = new FileInputStream(originalFile);
        out = new FileOutputStream(targetFile);
        int c;

        while ((c = in.read()) != -1) {		//reads the source file upto the end of the file 
            out.write(c);
        }

        out.close();
        in.close();

    }

}

