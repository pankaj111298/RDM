package FileTransfer;

import java.net.*; //net package for sockets
import java.io.*;  //io package for file transfer



public class Sender extends Thread{
    ServerSocket svr; //object of serversocket class
    Socket sct; //object of socket class
    File file; //object of fileclass

    public Sender(int port,String fileName) throws IOException{		//Parameterized Constructor of Sender class
        svr=new ServerSocket(port);
        file=new File(fileName);


    }  		 	  
    public void run(){			//Run method of inherited Thread class
        try{
            while(true){		//Infinite loop
                sct=svr.accept();
                sendFile();		//Calling of sendfile function
            }
        }catch(Exception e){
            e.printStackTrace();	//This function will provide details in which line exception is occured
        }
    }

    public void sendFile() throws IOException{     //Definition of sendfile function
        if(!file.exists()) {
            System.out.println("File does not exist");
            System.exit(-1);
        }

        if (file.exists()) {
            ObjectOutputStream OOS=new ObjectOutputStream(sct.getOutputStream());	//object of objectoutputstream writes Java objects to an OutputStream
            OOS.writeObject(file);
        }
    }

}
