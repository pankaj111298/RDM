package RemoteDesktopMonitoring;

import java.awt.*; //importing  Advanced Window Toolkit
import java.io.IOException;
import java.io.ObjectInputStream;
import javax.swing.*; //importing swing class from javax package
import java.net.*;


public class Sreceiver extends Thread{
    ObjectInputStream OI=null;
    Socket sc=null;
    JPanel jp;

    Sreceiver(Socket sc,JPanel jp){ //Constructor of Sreceiver class
        this.sc=sc;
        this.jp=jp;
    }

    public void run(){
        try{
            OI=new ObjectInputStream(sc.getInputStream());// initilization  of object of ObjectInputStream class

        }catch (IOException e){
            e.printStackTrace(); //This function will provide details in which line exception is occured
        }
        while(true){ //Infinite loop
            try{
                ImageIcon imageIcon = (ImageIcon) OI.readObject();//Coloured screenshot is painted with the help of imageIcon object 
                Image im=imageIcon.getImage(); //Receiving the image painted from imageIcon object
                im = im.getScaledInstance(1366,768,Image.SCALE_FAST); //dimensions for image 

                Graphics graphics = jp.getGraphics();//Getting screen device 
                graphics.drawImage(im,0,0, 1366,768,jp);
            }catch (Exception e){
                e.printStackTrace(); //This function will provide details in which line exception is occured

            }
        }
    }
}
