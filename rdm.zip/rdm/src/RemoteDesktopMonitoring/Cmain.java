package RemoteDesktopMonitoring;

import java.awt.*;	//importing Advance Window Toolkit package 
import java.io.ObjectOutputStream;		//importing ObjectOutputStream class from io package
import java.net.*; 	//net package for sockets 


public class Cmain extends Thread{	
    Socket socket = null;
    String IP;
    int port;
    Robot robot = null;	//Used to capture the screen  //class of  awt package 
    public Cmain(String IP,int port){		//constructor of Cmain class
        this.IP=IP;
        this.port=port;
    }
    public  void run(){	
        try{
            GraphicsEnvironment GE=GraphicsEnvironment.getLocalGraphicsEnvironment(); //Get default screen device 
            GraphicsDevice GD=GE.getDefaultScreenDevice();  


            robot=new Robot(GD);	//Prepare Robot object
            socket=new Socket(IP,port);

            Scapture scp=new Scapture(socket,robot);
            scp.start();

            Rcommand rc=new Rcommand(socket,robot);
            rc.start();
        }catch (Exception e){
            e.printStackTrace();	//This function will provide details in which line exception is occured

        }
    }
}
