package RemoteDesktopMonitoring;

import java.awt.*; 	//importing  Advanced Window Toolkit
import java.net.Socket;
import java.util.Scanner;
import java.awt.event.InputEvent; //importing Inputevent class from event class of AWT package 

public class Rcommand extends Thread{
    Scanner scanner=null;
    Socket socket;
    Robot robot; //object of Robot class used to  generate native systems input events 

    Rcommand(Socket sc,Robot rb){	//Constructor of Rcommand class 
        socket=sc;
        robot=rb;
    }
    public void run(){
        try{
            robot.setAutoWaitForIdle(true);	//sets whether this Robot automatically invokes waitForIdle after generating an event 
            scanner = new Scanner(socket.getInputStream()); 	

            while(true){	//Infinite loop
                int data= scanner.nextInt(); 
                if(data==-1) { 		// if  data = -1 then mousepress event will occur in native system 
                    int checkb=scanner.nextInt();
                    if(checkb==1) robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); //Invocation of mousepress function of native system
                    else if(checkb==3) robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);	//Invocation of mousepress function of native system
                    else if(checkb==2) robot.mousePress(InputEvent.BUTTON2_DOWN_MASK); //Invocation of mousepress function of native system
                    robot.delay(10);
                }
                else if(data ==-2 ) // if  data = -2 then mouseRelease event will occur in native system 
                {
                    int checkb=scanner.nextInt();
                    if(checkb==1) robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); //Invocation of mouseRelease function of native system	
                    else if(checkb==3) robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK); //Invocation of mouseRelease function of native system
                    else if(checkb==2) robot.mouseRelease(InputEvent.BUTTON2_DOWN_MASK); //Invocation of mouseRelease function of native system
                    robot.delay(10);
                }
                else if (data == -3) // if  data = -3 then mouseMove  event will occur in native system 
				robot.mouseMove(scanner.nextInt(),scanner.nextInt()); //Invocation of mouseMove function of native system
                else if (data == -4) {

                }
                else if (data == -5) { // if  data = -5 then keyPress event will occur in native system 
                    robot.keyPress(scanner.nextInt()); //Invocation of keyPress function of native system
                    robot.delay(10);
                }
                else if (data == -6) { // if  data = -1 then keyRelease event will occur in native system 
                    robot.keyRelease(scanner.nextInt()); //Invocation of keyRelease function of native system
                    robot.delay(10);
                }
            }

        }catch(Exception e){}
    }
}

