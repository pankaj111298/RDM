package RemoteDesktopMonitoring;

import javax.swing.*;	//importing swing class from javax package
import java.awt.event.*; //importing  Advanced Window Toolkit
import java.io.*;
import java.net.*; 


public class Scommand extends Thread{
    JPanel jP; //object of swings panel class 
    PrintWriter print=null; //object of PrintWriter class 
    Socket st=null;
    Scommand(Socket st,JPanel jP){  // Constructor of Scommand class
        this.st=st;
        this.jP=jP;
    }

    public void run(){
        try {
            print = new PrintWriter(st.getOutputStream());
        }catch (IOException e){
            e.printStackTrace();
        }
        command Cmnd=new command();//object of command class  
        jP.addKeyListener(Cmnd); //calling of function defined in command class from jPanels object
        jP.addMouseListener(Cmnd); //calling of function defined in command class from jPanels object
        jP.addMouseMotionListener(Cmnd); //calling of function defined in command class from jPanels object

    }

    class command implements KeyListener,MouseMotionListener,MouseListener,MouseWheelListener{ // Definition of commannd class 
        //Key Listener
        public void keyTyped(KeyEvent e){}  
        public void	keyPressed(KeyEvent e){
            int temp1=-5; //-5 value given for key pressed in Rcommand class
            print.println(temp1); //
            print.println(e.getKeyCode());//will print the virtual key codes returned by getKeyCode (which key is pressed/released)
            print.flush(); //saving of characters from write() in buffered stream 
        }
        public void	keyReleased(KeyEvent e){
            int temp2=-6;
            print.println(temp2); //-6 value given for key released in Rcommand class
            print.println(e.getKeyCode());//will print the virtual key codes returned by getKeyCode (which key is pressed/released)
            print.flush(); //saving of characters from write() in buffered stream 
        }

        //Mouse Listener
        public void mouseClicked(MouseEvent e){}
        public void mouseEntered(MouseEvent e){}
        public void	mouseExited(MouseEvent e){}
        public void	mousePressed(MouseEvent e){
            int temp5=-1;
            print.println(temp5);
            print.println(e.getButton());
            print.flush();
        }
        public void	mouseReleased(MouseEvent e){
            int temp6=-2;
            print.println(temp6);
            print.println(e.getButton());
            print.flush();
        }

        //Mouse motion
        public void	mouseDragged(MouseEvent e){}
        public void	mouseMoved(MouseEvent e){
            int temp3=-3;//-3 value given for mouse functionatily in Rcommand class 
            print.println(temp3);
            print.println(e.getX());//printing of x coordinates of mouse moved/dragged
            print.println(e.getY());//printing of y coordinates of mouse moved/dragged
            print.flush();
        }

        //Mouse Wheel
        public void	mouseWheelMoved(MouseWheelEvent e) {
            int temp4 = -4;
            print.println(temp4);//-4 value given for mouse functionatily in Rcommand class 
            int notches = e.getWheelRotation();//storing value of position returned from getWheelRotation
            print.println(notches);
            print.flush();//saving of characters from write() in buffered stream

        }

    }
}

