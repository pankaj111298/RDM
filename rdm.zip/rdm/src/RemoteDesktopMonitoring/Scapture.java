package RemoteDesktopMonitoring;

import javax.swing.*;	//importing swing class from javax package
import java.awt.*;	//importing  Advanced Window Toolkit
import java.awt.image.BufferedImage; //importing of BufferredImage subclass to handle image data 
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Scapture extends Thread {		
    ObjectOutputStream OS=null;
    Socket socket=null;
    Robot robot=null;
    Scapture(Socket sc,Robot rb){	//Constructor of Scapture class 
        socket=sc;
        robot=rb;
    }
    public void run(){
        try{
            OS = new ObjectOutputStream(socket.getOutputStream()); //initialization of object of  ObjectOutputStream class 
            //OS.writeObject(rec);
            while(true){
                BufferedImage BI=robot.createScreenCapture(new Rectangle(0,0,1366,768)); //Screenshots captured from robot class method are stored in buffered image object 
                ImageIcon image=new ImageIcon(BI);	//Coloured screenshot is painted with the help of imageIcon object 

                try {
                    OS.writeObject(image);  //helps to transfer the image with object of ObjectOutputStream
                    OS.reset();
                }catch (IOException e)   {
                    e.printStackTrace(); //This function will provide details in which line exception is occured
                }

                try{
                    Thread.sleep(100); 	//sleep function is called of Thread class 
                }catch (InterruptedException e){
                    e.printStackTrace();	//This function will provide details in which line exception is occured
                }
            }


        }catch(Exception e){
            e.printStackTrace();	//This function will provide details in which line exception is occured
        }
    }
}
