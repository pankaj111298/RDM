package RemoteDesktopMonitoring;

import java.awt.*; //importing Advance Window Toolkit package 
import javax.swing.*;
import java.net.*; //net package for sockets 


public class Smain extends Thread{
    int port;
     InetAddress a; //InetAddress class is used to get the IP of any host name 
    public Smain(int port){ //constructor of Smain class
        this.port=port;
        this.a=a;
    }
    public void run(){
        try{
            a=InetAddress.getLocalHost();
            ServerSocket serversocket=new ServerSocket(port); //
            Socket socket=serversocket.accept();

            JFrame JF = new JFrame();
            JDesktopPane JD = new JDesktopPane();
            JInternalFrame JI = new JInternalFrame("Client Screen", true, true, true);
            JPanel JP = new JPanel();
	    //Calling of functions for designing of IF,JD,JF
            JI.setLayout(new BorderLayout());
            JI.getContentPane().add(JP, BorderLayout.CENTER);
            JI.setSize(1366, 768);
            JD.add(JI);
            JP.setFocusable(true);
            JI.setVisible(true);
            JF.add(JD, BorderLayout.CENTER);
            JF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JF.add(JP);
            JF.setTitle(" "+a);
            JF.setSize(1366, 768);
            JF.setVisible(true);

            Sreceiver sr=new Sreceiver(socket,JP);//object of Sreceiver class 
            sr.start();
            Scommand sc=new Scommand(socket,JP);//object of SCommand class 
            sc.start();
        }catch (Exception e){
            e.printStackTrace(); //This function will provide details in which line exception is occured


        }
    }

}

