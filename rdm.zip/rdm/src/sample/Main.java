package sample;

import javafx.application.Application;//for  application life-cycle classes
import javafx.fxml.FXMLLoader; //imports classes for object hierarchy from markup
import javafx.scene.Parent;//imports basic classes for javafx API
import javafx.scene.Scene;
import javafx.stage.Stage;//contains top-level container classes of javafx content
 
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{ //called after init method in javafx applications
        Parent root = FXMLLoader.load(getClass().getResource("GUI.fxml"));//loads an object hierarchy  of fxml document
        primaryStage.setTitle("RDM (PANKAJ and AASHISH)");
        primaryStage.setScene(new Scene(root, 600, 400));//for specifying scene to use on the stage 
        primaryStage.show();//to show the window by making visibility true
    }


    public static void main(String[] args) {
        launch(args); //for lauching standalone application
    }
}
